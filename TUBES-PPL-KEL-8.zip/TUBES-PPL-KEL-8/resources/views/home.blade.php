@extends('layouts.app')

@section('content')
    <h3>Selamat datang di KosNyaman</h3>
@endsection
