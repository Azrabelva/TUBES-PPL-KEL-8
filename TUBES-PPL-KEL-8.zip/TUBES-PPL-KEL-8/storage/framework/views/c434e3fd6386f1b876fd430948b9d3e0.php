<?php $__env->startSection('content'); ?>


<div class="container mb-4">
    <div class="card shadow-sm p-3">
        <div class="row g-3 align-items-center">

            <div class="col-md-5">
                <input type="text" class="form-control" placeholder="Cari lokasi kos...">
            </div>

            <div class="col-md-3">
                <select class="form-select">
                    <option selected>Semua tipe</option>
                    <option>Kos Putra</option>
                    <option>Kos Putri</option>
                    <option>Kos Campur</option>
                </select>
            </div>

            <div class="col-md-3">
                <input type="date" class="form-control">
            </div>

            <div class="col-md-1">
                <button class="btn btn-primary w-100">Cari</button>
            </div>

        </div>
    </div>
</div>



<div class="container">
    <h4 class="mb-3">Rekomendasi Hunian</h4>

    <div class="row">

        
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 mb-4">

            <div class="card shadow-sm">
                <img src="<?php echo e($k->foto_kos); ?>" width="300" height="200"
                     class="card-img-top mt-1" alt="Foto Kos">

                <div class="card-body">
                    <span class="badge bg-secondary">Kos</span>

                    <h5 class="mt-2"><?php echo e($k->nama); ?></h5>

                    <p class="text-muted mb-1"><?php echo e($k->alamat); ?></p>

                    <h6 class="text-danger fw-bold">Rp<?php echo e(number_format($k->kamars()->min('harga') ?? 0, 0, ',', '.')); ?> / bulan</h6>

                    <a href="#" class="btn btn-outline-primary w-100 mt-2">Lihat Detail</a>
                </div>
            </div>

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\TELKOM UNIVERSITY\5th SEMESTER\Proyek Perangkat Lunak IS-06-03\tubes_ppl\TUBES-PPL-KEL-8\resources\views/kos/index.blade.php ENDPATH**/ ?>